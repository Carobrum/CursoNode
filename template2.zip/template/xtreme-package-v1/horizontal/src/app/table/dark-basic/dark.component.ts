import { Component } from '@angular/core';
@Component({
  templateUrl: './dark.component.html'
})
export class DarktableComponent {}
