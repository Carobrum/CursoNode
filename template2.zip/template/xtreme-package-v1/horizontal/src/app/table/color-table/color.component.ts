import { Component } from '@angular/core';
@Component({
  templateUrl: './color.component.html'
})
export class ColortableComponent {}
