import { Component, AfterViewInit } from '@angular/core';

@Component({
  templateUrl: './dashboard6.component.html',
  styleUrls: ['./dashboard6.component.css']
})
export class Dashboard6Component implements AfterViewInit {
  constructor() {}

  ngAfterViewInit() {}
}
