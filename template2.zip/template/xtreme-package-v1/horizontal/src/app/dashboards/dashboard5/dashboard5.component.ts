import { Component, AfterViewInit } from '@angular/core';

@Component({
  templateUrl: './dashboard5.component.html',
  styleUrls: ['./dashboard5.component.css']
})
export class Dashboard5Component implements AfterViewInit {
  constructor() {}

  ngAfterViewInit() {}
}
