import { Component } from '@angular/core';
@Component({
  selector: 'app-product-approval',
  templateUrl: './pro-appr.component.html'
})
export class ProapprComponent {
  constructor() {}
}
