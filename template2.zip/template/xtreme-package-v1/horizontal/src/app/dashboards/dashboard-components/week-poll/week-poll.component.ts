import { Component } from '@angular/core';
@Component({
  selector: 'app-week-poll',
  templateUrl: './week-poll.component.html'
})
export class WeekpollComponent {
  constructor() {}
}
