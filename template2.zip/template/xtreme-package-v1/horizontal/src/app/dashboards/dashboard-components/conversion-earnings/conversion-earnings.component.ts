import { Component } from '@angular/core';
@Component({
  selector: 'app-conversion-earnings',
  templateUrl: './conversion-earnings.component.html',
  styleUrls: ['./conversion-earnings.component.css']
})
export class ConversionEarningsComponent {
  constructor() {}
}
