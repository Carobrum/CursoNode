import { Component } from '@angular/core';
@Component({
  selector: 'app-weathercard',
  templateUrl: './weathercard.component.html'
})
export class WeathercardComponent {
  constructor() {}
}
