import { Component } from '@angular/core';
@Component({
  selector: 'app-social',
  templateUrl: './social.component.html'
})
export class SocialComponent {
  constructor() {}
}
