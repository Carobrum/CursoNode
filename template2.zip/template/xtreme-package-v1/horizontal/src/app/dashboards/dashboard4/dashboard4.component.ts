import { Component, AfterViewInit } from '@angular/core';

@Component({
  templateUrl: './dashboard4.component.html',
  styleUrls: ['./dashboard4.component.css']
})
export class Dashboard4Component implements AfterViewInit {
  constructor() {}

  ngAfterViewInit() {}
}
