import { Component, AfterViewInit } from '@angular/core';

@Component({
  templateUrl: './dashboard7.component.html',
  styleUrls: ['./dashboard7.component.css']
})
export class Dashboard7Component implements AfterViewInit {
  constructor() {}

  ngAfterViewInit() {}
}
