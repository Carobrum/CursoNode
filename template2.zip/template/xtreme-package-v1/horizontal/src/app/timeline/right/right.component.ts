import { Component } from '@angular/core';

@Component({
  templateUrl: 'right.component.html'
})
export class RightComponent {}
