import { Component } from '@angular/core';

@Component({
  templateUrl: 'center.component.html'
})
export class CenterComponent {}
