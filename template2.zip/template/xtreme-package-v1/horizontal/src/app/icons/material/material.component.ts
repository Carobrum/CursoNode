import { Component } from '@angular/core';
@Component({
  templateUrl: 'material.component.html'
})
export class MaterialComponent {}
