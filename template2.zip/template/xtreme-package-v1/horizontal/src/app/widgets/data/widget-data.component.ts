import { Component } from '@angular/core';
@Component({
  templateUrl: 'widget-data.component.html'
})
export class WidgetdataComponent {}
