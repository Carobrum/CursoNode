import { Component } from '@angular/core';
@Component({
  templateUrl: 'widget-app.component.html'
})
export class WidgetappComponent {}
